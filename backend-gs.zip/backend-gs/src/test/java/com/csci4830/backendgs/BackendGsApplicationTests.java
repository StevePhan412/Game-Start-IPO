package com.csci4830.backendgs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendGsApplicationTests {

	@Test
	void contextLoads() {
	}

}
