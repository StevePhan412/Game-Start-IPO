package com.csci4830.backendgs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendGsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendGsApplication.class, args);
	}

}
